// ============================================
// RAVANX - Frontend API Connector
// Save this as: frontend/public/js/api.js
// ============================================

const API_URL = 'http://localhost:5000/api'; // Change to your live URL in production

// ===== HELPER =====
async function apiCall(endpoint, method = 'GET', body = null) {
  const token = localStorage.getItem('rvx_token');
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {})
  };
  const res = await fetch(`${API_URL}${endpoint}`, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

// ===== AUTH =====
const Auth = {
  async register(name, email, password) {
    const data = await apiCall('/auth/register', 'POST', { name, email, password });
    localStorage.setItem('rvx_token', data.token);
    localStorage.setItem('rvx_user', JSON.stringify(data.user));
    return data;
  },

  async login(email, password) {
    const data = await apiCall('/auth/login', 'POST', { email, password });
    localStorage.setItem('rvx_token', data.token);
    localStorage.setItem('rvx_user', JSON.stringify(data.user));
    return data;
  },

  logout() {
    localStorage.removeItem('rvx_token');
    localStorage.removeItem('rvx_user');
    localStorage.removeItem('rvx_cart');
  },

  getUser() {
    return JSON.parse(localStorage.getItem('rvx_user') || 'null');
  },

  isLoggedIn() {
    return !!localStorage.getItem('rvx_token');
  },

  isAdmin() {
    const user = this.getUser();
    return user && user.role === 'admin';
  },

  async updateProfile(data) {
    return await apiCall('/auth/profile', 'PUT', data);
  }
};

// ===== PRODUCTS =====
const Products = {
  async getAll(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return await apiCall(`/products?${params}`);
  },

  async getById(id) {
    return await apiCall(`/products/${id}`);
  },

  async create(productData) {
    return await apiCall('/products', 'POST', productData);
  },

  async update(id, productData) {
    return await apiCall(`/products/${id}`, 'PUT', productData);
  },

  async delete(id) {
    return await apiCall(`/products/${id}`, 'DELETE');
  },

  async addReview(id, rating, comment) {
    return await apiCall(`/products/${id}/review`, 'POST', { rating, comment });
  }
};

// ===== ORDERS =====
const Orders = {
  async place(items, shippingAddress, paymentMethod = 'cod') {
    return await apiCall('/orders', 'POST', { items, shippingAddress, paymentMethod });
  },

  async getMyOrders() {
    return await apiCall('/orders/my');
  },

  async getById(id) {
    return await apiCall(`/orders/${id}`);
  },

  async cancel(id) {
    return await apiCall(`/orders/${id}/cancel`, 'PUT');
  }
};

// ===== ADMIN =====
const Admin = {
  async getDashboard() {
    return await apiCall('/admin/dashboard');
  },

  async getUsers() {
    return await apiCall('/admin/users');
  },

  async updateUser(id, data) {
    return await apiCall(`/admin/users/${id}`, 'PUT', data);
  },

  async getOrders(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return await apiCall(`/admin/orders?${params}`);
  },

  async updateOrderStatus(id, status, message) {
    return await apiCall(`/orders/${id}/status`, 'PUT', { status, message });
  }
};

// ===== PAYMENT =====
const Payment = {
  async createRazorpayOrder(amount) {
    return await apiCall('/payment/create-order', 'POST', { amount });
  },

  async verify(paymentData) {
    return await apiCall('/payment/verify', 'POST', paymentData);
  },

  async confirmCOD(orderId) {
    return await apiCall('/payment/cod', 'POST', { orderId });
  },

  // Open Razorpay popup
  openRazorpay(options) {
    return new Promise((resolve, reject) => {
      const rzp = new window.Razorpay({
        ...options,
        handler: (response) => resolve(response),
        modal: { ondismiss: () => reject(new Error('Payment cancelled')) }
      });
      rzp.open();
    });
  }
};

// Export for use in HTML
window.RvxAPI = { Auth, Products, Orders, Admin, Payment };
