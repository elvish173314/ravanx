const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

// @POST /api/payment/create-order - Create Razorpay order
router.post('/create-order', protect, async (req, res) => {
  try {
    // Razorpay integration
    // Install: npm install razorpay
    // const Razorpay = require('razorpay');
    // const razorpay = new Razorpay({
    //   key_id: process.env.RAZORPAY_KEY_ID,
    //   key_secret: process.env.RAZORPAY_KEY_SECRET,
    // });
    // const options = {
    //   amount: req.body.amount * 100, // in paise
    //   currency: 'INR',
    //   receipt: `receipt_${Date.now()}`,
    // };
    // const razorpayOrder = await razorpay.orders.create(options);
    // res.json({ success: true, order: razorpayOrder, key: process.env.RAZORPAY_KEY_ID });

    // TEST MODE (no Razorpay keys needed):
    const fakeOrder = {
      id: `order_test_${Date.now()}`,
      amount: req.body.amount * 100,
      currency: 'INR',
      status: 'created'
    };
    res.json({ success: true, order: fakeOrder, key: process.env.RAZORPAY_KEY_ID || 'rzp_test_key' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @POST /api/payment/verify - Verify Razorpay payment
router.post('/verify', protect, async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;

    // Verify signature
    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'test_secret')
      .update(body)
      .digest('hex');

    const isValid = expectedSignature === razorpay_signature;

    if (isValid || process.env.NODE_ENV === 'development') {
      // Mark order as paid
      const order = await Order.findByIdAndUpdate(orderId, {
        isPaid: true,
        paidAt: Date.now(),
        status: 'confirmed',
        paymentResult: { razorpay_order_id, razorpay_payment_id, razorpay_signature, status: 'paid' },
        $push: { statusHistory: { status: 'confirmed', message: 'Payment received' } }
      }, { new: true });

      res.json({ success: true, message: 'Payment verified!', order });
    } else {
      res.status(400).json({ success: false, message: 'Payment verification failed' });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @POST /api/payment/cod - Cash on Delivery
router.post('/cod', protect, async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findByIdAndUpdate(orderId, {
      status: 'confirmed',
      $push: { statusHistory: { status: 'confirmed', message: 'COD order confirmed' } }
    }, { new: true });
    res.json({ success: true, message: 'COD order confirmed!', order });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
