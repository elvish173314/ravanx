const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

// Note: Cart is stored in localStorage on frontend for speed.
// This endpoint is for syncing cart with server if needed.

// @GET /api/cart/validate - Validate cart items & get latest prices
router.post('/validate', protect, async (req, res) => {
  try {
    const Product = require('../models/Product');
    const { items } = req.body;
    const validated = [];

    for (const item of items) {
      const product = await Product.findById(item.id);
      if (product && product.isActive && product.stock > 0) {
        validated.push({
          id: product._id,
          name: product.name,
          price: product.price,
          oldPrice: product.oldPrice,
          stock: product.stock,
          image: product.images[0] || product.icon,
          qty: Math.min(item.qty, product.stock) // Cap at stock
        });
      }
    }

    res.json({ success: true, items: validated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
