# 🚀 RAVANX — Live Deployment Guide
# Poora website live karne ka step-by-step tarika

==================================================
## STEP 1 — Node.js Install Karo (Agar nahi hai)
==================================================

1. https://nodejs.org par jao
2. "LTS" version download karo
3. Install karo (Next > Next > Finish)
4. Terminal/CMD mein check karo:
   node --version   ✅ v18+ hona chahiye
   npm --version    ✅ 9+ hona chahiye


==================================================
## STEP 2 — MongoDB Atlas (Free Database)
==================================================

1. https://cloud.mongodb.com par jao
2. "Sign Up Free" karo
3. "Create a Free Cluster" choose karo (M0 - Free)
4. Region: Mumbai (ap-south-1) select karo
5. Cluster name: ravanx-db

6. "Database Access" mein jao:
   - "Add New Database User" click karo
   - Username: ravanx_user
   - Password: (koi strong password likho, yaad rakhna!)
   - Role: "Read and Write to Any Database"

7. "Network Access" mein jao:
   - "Add IP Address" click karo
   - "Allow Access from Anywhere" (0.0.0.0/0)

8. "Connect" button dabao:
   - "Connect your application" choose karo
   - Driver: Node.js, Version: 5.5+
   - Connection string copy karo:
     mongodb+srv://ravanx_user:PASSWORD@cluster0.xxxxx.mongodb.net/ravanx

9. Is string ko .env file mein daalo (MONGO_URI)


==================================================
## STEP 3 — Project Setup (Local)
==================================================

1. Yeh ravanx/ folder apne computer par save karo

2. Terminal mein jao backend folder mein:
   cd ravanx/backend

3. .env file banao (.env.example ko copy karke):
   - Windows:  copy .env.example .env
   - Mac/Linux: cp .env.example .env

4. .env file open karo aur fill karo:
   MONGO_URI=mongodb+srv://ravanx_user:yourpassword@cluster0.xxxxx.mongodb.net/ravanx
   JWT_SECRET=ravanx_my_super_secret_key_2026_xyz
   ADMIN_EMAIL=apnaemail@gmail.com

5. Dependencies install karo:
   npm install

6. Server start karo:
   npm run dev

7. Browser mein jao:
   http://localhost:5000/api/health
   
   Agar yeh dikhe: {"status":"OK","message":"RAVANX API is running!"}
   ✅ Backend kaam kar raha hai!


==================================================
## STEP 4 — Railway Par Live Deploy Karo (FREE)
==================================================

Railway = Free hosting, automatic HTTPS, easy deploy

1. GitHub account banao: https://github.com

2. apna code GitHub par upload karo:
   - GitHub Desktop download karo: https://desktop.github.com
   - "New Repository" banao: ravanx
   - ravanx/ folder ke files add karo
   - "Commit" aur "Push" karo

3. https://railway.app par jao
   - "Start a New Project" click karo
   - "Deploy from GitHub repo" select karo
   - Apna ravanx repo select karo

4. Railway project settings mein:
   - "Variables" tab mein jao
   - Yeh sab environment variables add karo:
   
   MONGO_URI      = (apna MongoDB Atlas URI)
   JWT_SECRET     = ravanx_super_secret_key_2026
   ADMIN_EMAIL    = apnaemail@gmail.com
   NODE_ENV       = production
   PORT           = 5000

5. "Deploy" button dabao
   Wait karo ~2 minutes...

6. Railway tumhe ek URL dega jaise:
   https://ravanx-production-xxxx.up.railway.app

7. Is URL par jao + /api/health:
   https://ravanx-production-xxxx.up.railway.app/api/health
   ✅ Live hai!


==================================================
## STEP 5 — Frontend Ko Backend Se Connect Karo
==================================================

1. frontend/public/js/api.js file mein:
   
   Purana:  const API_URL = 'http://localhost:5000/api';
   Naya:    const API_URL = 'https://ravanx-production-xxxx.up.railway.app/api';

2. HTML file mein yeh line add karo (</body> se pehle):
   <script src="js/api.js"></script>

3. Website par Sign Up karo with ADMIN_EMAIL se
   → Woh automatically Admin ban jayega!


==================================================
## STEP 6 — Custom Domain (Optional - Free!)
==================================================

Free domain: https://www.freenom.com (.tk, .ml domains free hain)
Ya Namecheap se: .com domain ~₹800/year

Railway mein:
1. Settings → Domains → "Add Custom Domain"
2. Type karo: ravanx.com (ya jo bhi domain lo)
3. DNS settings mein CNAME add karo (Railway batayega)
4. Wait karo ~15 min — done!


==================================================
## STEP 7 — Razorpay Payment Setup (Optional)
==================================================

1. https://razorpay.com par sign up karo
2. Dashboard → Settings → API Keys
3. "Test Mode" mein test keys lo
4. .env mein daalo:
   RAZORPAY_KEY_ID=rzp_test_xxxx
   RAZORPAY_KEY_SECRET=xxxx

5. backend/routes/payment.js mein uncomment karo Razorpay code

6. Production ke liye:
   - KYC complete karo
   - Live keys lo (rzp_live_xxxx)


==================================================
## ADMIN DASHBOARD
==================================================

Admin login karne ke baad:
https://yoursite.com/admin.html

Features:
✅ Dashboard stats (revenue, orders, users)
✅ Products add/edit/delete
✅ Orders manage (status update)
✅ Users list


==================================================
## QUICK REFERENCE — API Endpoints
==================================================

AUTH:
POST /api/auth/register   → Register
POST /api/auth/login      → Login
GET  /api/auth/me         → My profile
PUT  /api/auth/profile    → Update profile

PRODUCTS:
GET  /api/products        → All products
GET  /api/products/:id    → Single product
POST /api/products        → Create (Admin)
PUT  /api/products/:id    → Update (Admin)
DEL  /api/products/:id    → Delete (Admin)

ORDERS:
POST /api/orders          → Place order
GET  /api/orders/my       → My orders
PUT  /api/orders/:id/cancel → Cancel order

ADMIN:
GET  /api/admin/dashboard → Stats
GET  /api/admin/users     → All users
GET  /api/admin/orders    → All orders

PAYMENT:
POST /api/payment/create-order → Razorpay order
POST /api/payment/verify       → Verify payment
POST /api/payment/cod          → Cash on delivery


==================================================
## TROUBLESHOOTING
==================================================

❌ MongoDB connect nahi ho raha?
   → MONGO_URI check karo (password mein special chars? URL-encode karo)
   → Network Access mein 0.0.0.0/0 add karo

❌ "jwt is not defined" error?
   → JWT_SECRET .env mein daalo

❌ Railway deploy fail?
   → Logs check karo Railway dashboard mein
   → package.json mein "start" script check karo

❌ CORS error browser mein?
   → FRONTEND_URL env variable Railway mein set karo

💬 Help chahiye? Mujhe batao!
